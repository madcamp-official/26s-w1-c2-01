
  # Web-based Mind Mapping Tool

  This is a code bundle for Web-based Mind Mapping Tool. The original project is available at https://www.figma.com/design/HWZgqHt1raAmq5rWZYxFM0/Web-based-Mind-Mapping-Tool.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  